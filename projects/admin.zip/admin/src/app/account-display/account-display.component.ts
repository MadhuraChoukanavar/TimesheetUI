import { Component } from '@angular/core';

@Component({
  selector: 'app-account-display',
  templateUrl: './account-display.component.html',
  styleUrl: './account-display.component.css'
})
export class AccountDisplayComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-home-nav-bar',
  templateUrl: './home-nav-bar.component.html',
  styleUrl: './home-nav-bar.component.css'
})
export class HomeNavBarComponent {

}
